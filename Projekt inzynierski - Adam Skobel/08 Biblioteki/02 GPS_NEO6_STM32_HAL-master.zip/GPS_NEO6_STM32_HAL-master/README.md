GPS module NEO6MV2 with STM32 HAL. 

STM43F401RE
STM32CubeIDE 1.0.2
HAL F4 1.24.1

Description: 
GitHub: 
Contact: mateusz@msalamon.pl