/*
 * waitus.c
 *
 *  Created on: 27.11.2021
 *      Author: Adam
 */
#include "stm32f3xx_hal.h"

void waitus(uint32_t us)  // biblioteka generowania opoznienia w 'us'
{
  uint32_t i;
  for(i = 0; i < us; i++)
    {
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");  // x32 NOP [NOP - no operation]
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP");

	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");  // x32 NOP
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP"); asm("NOP");
	  	  asm("NOP"); asm("NOP");

    }
}


// Obliczenia
/*
 * 	Taktowanie zegara systemowego: 64MHz
 *
 *	Czas_trwania: 1us = 0,000001s
 *
 *	1_cykl_zegarowy_procesora: 1/64Mhz = 0.000000015625
 *
 *	Ilość potzrebnych do użycia instrukcji NOP: czas_trwania/1_cykl_zegarowy_procesora = 64
 *
 */
