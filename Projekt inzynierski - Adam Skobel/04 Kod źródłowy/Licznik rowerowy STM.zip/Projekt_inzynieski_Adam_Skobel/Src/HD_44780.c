/*
 * HD_44780.c
 *
 *  Created on: 27.11.2021
 *      Author: Adam
 */

#include "stm32f3xx_hal.h"
#include "main.h"
#include "waitus.h"

#define D7_set		HAL_GPIO_WritePin(LCD_DB7_GPIO_Port, LCD_DB7_Pin, GPIO_PIN_SET)
#define D7_reset	HAL_GPIO_WritePin(LCD_DB7_GPIO_Port, LCD_DB7_Pin, GPIO_PIN_RESET)
#define D6_set		HAL_GPIO_WritePin(LCD_DB6_GPIO_Port, LCD_DB6_Pin, GPIO_PIN_SET)
#define D6_reset	HAL_GPIO_WritePin(LCD_DB6_GPIO_Port, LCD_DB6_Pin, GPIO_PIN_RESET)
#define D5_set		HAL_GPIO_WritePin(LCD_DB5_GPIO_Port, LCD_DB5_Pin, GPIO_PIN_SET)
#define D5_reset	HAL_GPIO_WritePin(LCD_DB5_GPIO_Port, LCD_DB5_Pin, GPIO_PIN_RESET)
#define D4_set		HAL_GPIO_WritePin(LCD_DB4_GPIO_Port, LCD_DB4_Pin, GPIO_PIN_SET)
#define D4_reset	HAL_GPIO_WritePin(LCD_DB4_GPIO_Port, LCD_DB4_Pin, GPIO_PIN_RESET)

#define E_set		HAL_GPIO_WritePin(LCD_E_GPIO_Port, LCD_E_Pin, GPIO_PIN_SET)
#define E_reset		HAL_GPIO_WritePin(LCD_E_GPIO_Port, LCD_E_Pin, GPIO_PIN_RESET);
#define RS_set		HAL_GPIO_WritePin(LCD_RES_GPIO_Port, LCD_RES_Pin, GPIO_PIN_SET);
#define RS_reset	HAL_GPIO_WritePin(LCD_RES_GPIO_Port, LCD_RES_Pin, GPIO_PIN_RESET);

void write_lcd(uint8_t bajt)
{

	E_set;
    if(bajt&0x80)D7_set;else D7_reset;
    if(bajt&0x40)D6_set;else D6_reset;
    if(bajt&0x20)D5_set;else D5_reset;
    if(bajt&0x10)D4_set;else D4_reset;
    waitus(1);
    E_reset;
    waitus(1);
    E_set;
    if(bajt&0x8)D7_set;else D7_reset;
    if(bajt&0x4)D6_set;else D6_reset;
    if(bajt&0x2)D5_set;else D5_reset;
    if(bajt&0x1)D4_set;else D4_reset;
    E_reset;
    waitus(37);
}

void clear_lcd(void)
{
	RS_reset;
    write_lcd(1);
    RS_set
    waitus(1640);

}

void init_lcd2x8(void)	//	inicjalizacja zgodna z notą katalogową zamieszczoną w bibliografii (strona 46 - 4-Bit Interface)
{
    uint8_t i;

    waitus(400000);
    RS_reset;
    E_reset;
    D7_reset;
    D6_reset;
    D5_reset;
    D4_reset;
    waitus(1000);
    E_set;
    D7_reset;
    D6_reset;
    D5_set;
    D4_set;
    waitus(1);
    E_reset;
    waitus(4400);

    for(i = 0; i  >1; i++)
    {
    E_set;
    waitus(2);
    E_reset;
    waitus(200);
    }

    E_set;
    D4_reset;
    waitus(2);
    E_reset;

    RS_reset;
    write_lcd(0b00101000);
    RS_set;


    RS_reset;
    write_lcd(0b00001100);
    RS_set;


    RS_reset;
    write_lcd(0b00000110);
    RS_set;

    clear_lcd();

}

void lcd_goto(unsigned char y,unsigned char x)
{
    uint8_t n;
    if(y == 1)n = x-1;
    else n = 0x40 + x-1;

    n=n|0b10000000;

    RS_reset;
    write_lcd(n);
    RS_set;
    waitus(20);

}

void write_number(unsigned char number)
{
    RS_set;
    write_lcd(0b00110000|(number%10));

}

void write_sign(unsigned char sign)
{
    RS_set;
 write_lcd(sign);

}

void write_word(const unsigned char *word)
{
    while(*word)	//dopóki wartość na którą wskazuje wskaźnik nie jest równa 0
    {
     write_sign(*word);	//wpisuje wartość na którą wskazuje wskaźnik
     word++;	//zwiększa adres wskaźnika
    }
}
