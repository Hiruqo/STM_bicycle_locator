/*
 * gps.c
 *
 *  Created on: 27.11.2021
 *      Author: Adam
 */

#include "stm32f3xx_hal.h"
#include "HD_44780.h"

UART_HandleTypeDef huart1;

#define GPS_init_UART  HAL_UART_Receive_IT(&huart1, &GPS.receive, 1)	// przerwanie przechwytujące znak komunikatu
#define buf_size 5	// zmienna globalna dla liczby wierszów tabeli dwuwymiarowej

typedef struct{
	unsigned char string_data[70][buf_size];	// rezerwacja miejsca w pamięci na bufor danych
	unsigned char receive;
	unsigned char inkrementator[buf_size];
	unsigned char string_flag[buf_size];
	unsigned char a[buf_size];

}gps;

gps GPS;

void read_gps_data(unsigned char *string_data, unsigned char adr)
{
	if(GPS.string_flag[adr] == 1)	// rozpoczęcie zapisu z chwilą wykrycia flagi
	{
		if((*(string_data + (GPS.inkrementator[adr])) != GPS.receive) && ((GPS.inkrementator[adr]) < 5))
			// wykrywanie błędu w postaci niepoprawnego komunikatu
		{
			GPS.string_flag[adr] = 0;
			GPS.inkrementator[adr] = 0;
		}
		if((GPS.inkrementator[adr]) >= 5 && GPS.receive != '\n')	// sprawdzenie końca transmisji jednego ciągu znaków
		{
			GPS.string_data[GPS.a[adr]][adr] = GPS.receive;
			GPS.a[adr]++;
		}
		if((GPS.string_flag[adr]) != 0)		// przesuwanie się wzdłuż długości komunikatu
		{
			GPS.inkrementator[adr]++;
		}
		if(GPS.receive == '\n')		// wykrywanie końca komunikatu i zerowanie zmiennych pomocniczych
		{
			GPS.inkrementator[adr] = 0;
			GPS.string_flag[adr] = 0;
			GPS.a[adr] = 0;
		}
	}
	if(GPS.receive == '$')GPS.string_flag[adr] = 1;		// flaga wykrycia znaku $ komunikatu NMEA
}

//unsigned char check_position(uint8_t adr, uint8_t wykrywany_znak, uint8_t pozycja)
//{
//	uint8_t a = 0,
//			b = 0;
//
//	while(GPS.string_data[a][adr] != '\n')
//	{
//		if(GPS.string_data[a][adr] == wykrywany_znak && a == pozycja)
//		{
//			b = 1;
//		}
//		a++;
//	}
//
//	return b;
//}

void number_comma(uint8_t adr, uint8_t comma_nr, uint8_t *h, uint8_t *data)
{
	uint8_t a = 0,b = 0;
	uint8_t comma_count = 0;
	uint8_t number = 0;
	uint8_t flag = 0;

	while(GPS.string_data[a][adr] != '\r')	// sprawdzanie znaku końca linii
	{
		a++;
		if(a > 80){
			flag = 1;
			break;
		}
	}
	a = 0;
	if(flag == 0)
	{
		while(1)
		{
			if(comma_nr == comma_count)
			{
				if(GPS.string_data[a][adr] == ',' && flag == 0)
				{
					flag = 2;
				}
				if(flag == 3)
				{
					a++;
				}
				if(flag == 3 && GPS.string_data[a][adr] == ',')		// tj. flaga wykrycia przecinka
				{
					a++;
					flag = 4;
				}
				if(flag == 3 && GPS.string_data[a][adr] == '\r')	// tj. flaga wykrycia znaku końca linii
				{
					flag = 4;
					number = 0;
				}
				if(flag == 3)
				{
					(number)++;
				}
				if(flag == 2)
				{
					flag = 3;
				}
			}
			if(comma_nr != comma_count)		// jeśli nie wykryto przecinka to program szuka dalej
			{
				a++;
				if(GPS.string_data[a][adr] == ',' && a > 0)		// wykrycie przecinka
				{
					comma_count++;
					if(comma_nr == comma_count)
					{
						b = a;
					}
				}
				if(GPS.string_data[a][adr] == '\n')		// jak szybciej wykryje koniec w buforze danych to wychodzi z funkcji i zwraca 0 do *h
				{
					flag = 4;
					number = 0;
				}
			}
			if(flag == 4)
			{
				break;
			}

		}

	}
	*h = number;
	*data = b;

}

void MENU(uint8_t menu)
{
	if(menu == 0)
	{
		uint8_t znak;
		uint8_t ilosc;

		number_comma(0, 0, &ilosc, &znak);

		if(ilosc == 9)
		{

			uint8_t temporary = (GPS.string_data[znak+1][0] & (0x0F))* 10	// złączenie 2 znaków godziny w liczbę dwócyfrową
							  + (GPS.string_data[znak+2][0] & (0x0F));
			temporary += 1;		// poprawka dla UTC+1
			if(temporary >= 24)	// warunek dla północy
			{
				temporary = 0;
			}

			lcd_goto(1,1);
//			write_sign(GPS.string_data[znak+1][0]);
//			write_sign(GPS.string_data[znak+2][0]);
			write_number(temporary/10);
			write_number(temporary%10);
			write_sign(':');
			write_sign(GPS.string_data[znak+3][0]);
			write_sign(GPS.string_data[znak+4][0]);
			write_sign(':');
			write_sign(GPS.string_data[znak+5][0]);
			write_sign(GPS.string_data[znak+6][0]);
		}
		else
		{
			lcd_goto(1,1);
			write_word("LOADING!");
		}

		lcd_goto(2,1);
		write_word("strona 1");

	}

	if(menu == 1)
	{
		uint8_t znak;
		uint8_t ilosc;

		number_comma(0, 8, &ilosc, &znak);

		if(ilosc == 6)
		{
			lcd_goto(1,1);
		 	write_sign(GPS.string_data[znak+1][0]);
		 	write_sign(GPS.string_data[znak+2][0]);
		 	write_sign('.');
		 	write_sign(GPS.string_data[znak+3][0]);
		 	write_sign(GPS.string_data[znak+4][0]);
		    write_sign('.');
		    write_sign(GPS.string_data[znak+5][0]);
		 	write_sign(GPS.string_data[znak+6][0]);
		 }
		else
		{
			lcd_goto(1,1);
			write_word("LOADING!");
		}

		lcd_goto(2,1);
		write_word("strona 2");
	}

	if(menu == 2)	// longitude N/S
	{
		uint8_t znak;
		uint8_t ilosc;

		number_comma(0, 2, &ilosc, &znak);

		if(ilosc == 10)
		{
			lcd_goto(1,1);
			write_sign(GPS.string_data[znak+1][0]);
			write_sign(GPS.string_data[znak+2][0]);
			write_sign(0xDF);
			write_sign(GPS.string_data[znak+3][0]);
			write_sign(GPS.string_data[znak+4][0]);
			write_sign(0x27);
			write_sign(' ');
			write_sign(' ');

			lcd_goto(2,1);
			// zapisanie do zmiennej tymczasowej liczby po przecinku
			uint32_t temporary = (GPS.string_data[znak+6][0] & (0x0F))*1000
							   + (GPS.string_data[znak+7][0] & (0x0F))*100
							   + (GPS.string_data[znak+8][0] & (0x0F))*10
							   + (GPS.string_data[znak+9][0] & (0x0F));

			// wartość pożądana to 60-krotność wartości liczby po przecinku
			// wartość jest mnożona ze względu na potrzebę wyliczenia danych dotyczących sekund dla położenia geograficznego
			temporary = (6 * temporary)/10;

			write_number(temporary/1000);
			write_number(temporary/100);
			write_sign('.');
			write_number(temporary/10);
			write_number(temporary%10);
			write_sign(0x22);
			write_sign(' ');
			write_sign(GPS.string_data[znak+12][0]); // znak kierunkowy dla długości geograficznej (N/S)
		}
		else
		{
			lcd_goto(1,1);
			write_word("LOADING!");
		}

//		lcd_goto(2,1);
//		write_word("strona 3");
	}

	if(menu == 3)	// latitude E/W
	{
		uint8_t znak;
		uint8_t ilosc;

		number_comma(0, 4, &ilosc, &znak);

		if(ilosc == 11)
		{
			lcd_goto(1,1);
			write_sign(GPS.string_data[znak+2][0]);
			write_sign(GPS.string_data[znak+3][0]);
			write_sign(0xDF);
			write_sign(GPS.string_data[znak+4][0]);
			write_sign(GPS.string_data[znak+5][0]);
			write_sign(0x27);
			write_sign(' ');
			write_sign(' ');

			lcd_goto(2,1);
			uint32_t temporary = (GPS.string_data[znak+7][0] & (0x0F))*1000
							   + (GPS.string_data[znak+8][0] & (0x0F))*100
							   + (GPS.string_data[znak+9][0] & (0x0F))*10
							   + (GPS.string_data[znak+10][0] & (0x0F));

			temporary = (6 * temporary)/10;

			write_number(temporary/1000);
			write_number(temporary/100);
			write_sign('.');
			write_number(temporary/10);
			write_number(temporary%10);
			write_sign(0x22);
			write_sign(' ');
			write_sign(GPS.string_data[znak+13][0]);
		}
		else
		{
			lcd_goto(1,1);
			write_word("LOADING!");
		}

//		lcd_goto(2,1);
//		write_word("strona 4");
	}

	if(menu == 4)	// speed km/h
	{
		uint8_t znak;
		uint8_t ilosc;

		number_comma(1, 6, &ilosc, &znak);

		if(ilosc >= 5)
		{
			lcd_goto(1,1);
			write_sign(GPS.string_data[znak+1][1]);
			write_sign(GPS.string_data[znak+2][1]);
			write_sign(GPS.string_data[znak+3][1]);
			write_sign(GPS.string_data[znak+4][1]);
			write_word("km/h");
		}
		else
		{
			lcd_goto(1,1);
			write_word("LOADING!");
		}

//		number_comma(1, 4, &ilosc, &znak);		prędkość w węzłach
//		if(ilosc >= 5)
//		{
//			lcd_goto(2,1);
//			write_sign(GPS.string_data[znak+1][1]);
//			write_sign(GPS.string_data[znak+2][1]);
//			write_sign(GPS.string_data[znak+3][1]);
//			write_sign(GPS.string_data[znak+4][1]);
//			write_sign(GPS.string_data[znak+5][1]);
//			write_word("wez");
//		}

		lcd_goto(2,1);
		write_word("strona 5");
	}
}

void init_gps()		// inicjalizacja GPS'a
{
	GPS_init_UART;
}
