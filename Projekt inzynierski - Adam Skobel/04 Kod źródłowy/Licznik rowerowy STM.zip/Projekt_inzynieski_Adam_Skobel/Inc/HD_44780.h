/*
 * HD_44780.h
 *
 *  Created on: 27.11.2021
 *      Author: Adam
 */

#ifndef HD_44780_H_
#define HD_44780_H_

void write_lcd(unsigned char bajt);
void clear_lcd(void);
void init_lcd2x8(void);
void lcd_goto(unsigned char y,unsigned char x);
void write_number(unsigned char number);
void write_sign(unsigned char sign);
void write_word(unsigned char *word);

#endif /* MY_LIB_MY_SRC_HD_44780_H_ */
