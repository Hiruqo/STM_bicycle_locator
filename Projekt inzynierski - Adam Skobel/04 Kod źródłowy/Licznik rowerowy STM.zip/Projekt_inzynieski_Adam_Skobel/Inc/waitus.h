/*
 * waitus.h
 *
 *  Created on: 27.11.2021
 *      Author: Adam
 */

#ifndef WAITUS_H_
#define WAITUS_H_

void waitus(uint32_t us);

#endif /* WAITUS_H_ */
