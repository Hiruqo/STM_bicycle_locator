/*
 * gps.h
 *
 *  Created on: 27.11.2021
 *      Author: Adam
 */

#ifndef INC_GPS_H_
#define INC_GPS_H_

#define buf_size 5

typedef struct{
	unsigned char string_data[70][buf_size];
	unsigned char receive;
	unsigned char inkrementator[buf_size];
	unsigned char string_flag[buf_size];
	unsigned char a[buf_size];

}gps;

//unsigned char check_position(uint8_t adr, uint8_t wykrywany_znak, uint8_t pozycja);

void read_gps_data(unsigned char *string_data, unsigned char adr);
void number_comma(uint8_t adr,uint8_t comma_nr,uint8_t *h,uint8_t *data);
void MENU(uint8_t menu);
void init_gps();

#endif /* INC_GPS_H_ */
